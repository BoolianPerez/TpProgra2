package Almacen;

public class Conexion {
    private int idConexion;
    private ListaPasillos adyacentes;
}
