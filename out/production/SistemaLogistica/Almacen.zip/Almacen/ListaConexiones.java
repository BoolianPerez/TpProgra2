package Almacen;

public class ListaConexiones {
    private NodoConexion primero;

    public ListaConexiones() {
        this.primero = null;
    }


}
