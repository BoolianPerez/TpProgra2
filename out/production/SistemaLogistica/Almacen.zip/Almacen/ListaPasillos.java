package Almacen;

public class ListaPasillos {
    private NodoPasillo primero;
}
